# -*- coding: utf-8 -*-
import scrapy
import os
from bs4 import BeautifulSoup
from scrapy.linkextractors import LinkExtractor
from scrapy.contrib.spiders import Rule, CrawlSpider
from urlparse import urlparse
from lyhuong.items import LyhuongItem
import requests
import pickle
import hashlib
import sys
from lockfile import LockFile
import time
reload(sys)
sys.setdefaultencoding('utf-8')
item_list = []
lock = LockFile('save_url.txt')
#ff = open('save_url.txt','a+',os.O_NONBLOCK)
def gen_bad_JS():
	f = open('badJS.txt','r')
	line = f.readline()[:-2]
	badJS = list()
	while (line != ''):
		badJS.append(line)
		line = f.readline()[:-2]
	return badJS
def find_domain(url):
	parsed_uri = urlparse(url)
	domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
	return domain
def check_JS(url, bad,js_all):
	dir_name = url.replace('/','_')
	domain = find_domain(url)
	for i in range (0,len(js_all)):
		item = LyhuongItem()
		#check script nhung trong html
		if not js_all[i].xpath('@src').extract():
			js_all[i] = js_all[i].extract()
			for do in bad:
				do = do[0:do.rfind('.')] 
				if(do in js_all[i]):
					text = str(url) + ' | '+ str(i) + ' | ' + hashlib.md5(js_all[i]).hexdigest() + ' | ' + 'nan'
					while(lock.is_locked()):
						print 'wait'
					if not lock.is_locked():
						lock.acquire()
						ff = open('save_url.txt','a')
						ff.write(text)
						ff.write('\n')
						lock.release()
						time.sleep(2)
					path = os.path.join('lyhuong',dir_name)
					if not os.path.exists(path):
						os.makedirs(path)
					file_name = os.path.join(path,str(i))
					f = open(file_name,'w')
					f.write(js_all[i])
					f.close()
					break
		#chekc script lien ket ra ngaoai
		else:
			js = js_all[i].xpath('@src').extract()[0]
			if js.startswith('/'):
				js = js.replace('/','',1)
				if not js.startswith('/'):
					js = domain + '/' + js
				else: 
					js = js.replace('/','',1)
					if(js[0:4] != 'http'):
						js = 'http://'+js
					
			r = requests.get(js)
			responses = r.text
			for do in bad:
				do = do[0:do.rfind('.')]
				if((do in responses) or (do in js)):
					text = str(url) + ' | '+ str(i) + ' | ' + hashlib.md5(responses).hexdigest() + ' | ' + js
					while(lock.is_locked()):
						print 'wait'
					if not lock.is_locked():
						lock.acquire()
						ff = open('save_url.txt','a')
						ff.write(text)
						ff.write('\n')
						lock.release()
						time.sleep(2)
					path = os.path.join('lyhuong',dir_name)
					if not os.path.exists(path):
						os.makedirs(path)
					file_name = os.path.join(path,str(i))
					f = open(file_name,'w')
					f.write(responses)
					f.close()

badJS = gen_bad_JS()

if not os.path.exists('baogiaothong'):
	os.makedirs('baogiaothong')
class LhSpider(scrapy.contrib.spiders.CrawlSpider):
	name = 'lyhuong'
	allowed_domains = ['lyhuong.net']
	start_urls = ['http://www.lyhuong.net/']
	rules = ( 
		Rule(LinkExtractor(allow_domains=allowed_domains,canonicalize = False, unique = True), follow=True,callback="parse_items" ),
)
	def parse_items(self, response):
		js_all = response.css('script')	
		check_JS(response.request.url,badJS,js_all)
		return
