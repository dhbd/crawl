from bs4 import BeautifulSoup
import os
import requests
import hashlib
from urlparse import urlparse
import time
import datetime
from lockfile import LockFile
from datetime import datetime
from threading import Timer
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
class APTItem:
	url = ''
	indx= ''
	hash_md5 = ''
	js_url = ''
def find_domain(url):
	parsed_uri = urlparse(url)
	domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
	return domain
def checkJS(data,item):
	soup = BeautifulSoup(data,'html.parser')
	js_all = soup.find_all('script')
	domain = find_domain(item.url)
	if(js_all[int(item.indx)].get('src')):
		js = js_all[int(item.indx)].get('src')
		if js.startswith('/'):
			js = js.replace('/','',1)
			if not js.startswith('/'):
				js = domain + '/' + js
			else: 
				js = js.replace('/','',1)
				if(js[0:4] != 'http'):
					js = 'http://'+js
		req = requests.get(js)
		response = req.text
		md5 = hashlib.md5(response).hexdigest()
		if(md5 == item.hash_md5):
			path = os.path.join('spiders','lyhuong',item.url.replace('/','_'), item.indx)
			f = open(path,'w')
			f.write(response)
			f.close()
		else:
			print 'good'
	else:
		md5 = hashlib.md5(str(js_all[int(item.indx)])).hexdigest()
		if(md5 == item.hash_md5):
			path = os.path.join('spiders','lyhuong',item.url.replace('/','_'), item.indx)
			f = open(path,'w')
			f.write(str(js_all[int(item.indx)]))
			f.close()
		else:
			print 'good'
def monitor():
	print '1'
	lock = LockFile('spiders/save_url.txt')
	ff = open('spiders/save_url.txt','r+')
	item_list = []
	while(lock.is_locked()):
		print 'wait'
	if not lock.is_locked():
		lock.acquire()
		line = ff.readline()
		print line		
		lock.release()
		time.sleep(2)
	while(line != ''):
		item = APTItem()
		item.url, item.indx, item.hash_md5, item.js_url = line.split(' | ')
		item_list.append(item)
		r = requests.get(item.url)
		time.sleep(10)
		data = r.text
		checkJS(data, item)
		while(lock.is_locked()):
			print 'wait'
		if not lock.is_locked():
			lock.acquire()
			line = ff.readline()
			print line
			lock.release()
			time.sleep(2)
x = datetime.today()
y = x.replace(day=x.day, hour=x.hour, minute=x.minute+1, second=0, microsecond=0)
delta_t = y - x
secs = delta_t.seconds+1
print 'zxc'
t = Timer(secs, monitor)
t.start()
